<?php

$meta = [
    'title' => 'İletişim'
];

require view('contact');