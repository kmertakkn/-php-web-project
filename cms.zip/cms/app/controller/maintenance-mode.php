<?php

require PATH . '/app/view/maintenance-mode.php';