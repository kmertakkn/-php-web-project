<?php require admin_view('static/header') ?>



<?php require admin_view('static/footer') ?>