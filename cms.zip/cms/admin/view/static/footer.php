<?php if (session('user_rank') && session('user_rank') != 3): ?>
    </div>
<?php endif; ?>

</body>
</html>